# DEBUG = True
 
# DIALECT = 'mysql'
# DIRVER = 'pymysql'
# USERNAME = 'root'
# PASSWORD = '123456'
# HOST = 'localhost'
# PORT = '3306'
# DATABASE = 'db'
# SQLALCHEMY_DATABASE_URI = "{}+{}://{}:{}@{}:{}/{}?charset=utf8".format(DIALECT, DIRVER, USERNAME, PASSWORD, HOST, PORT, DATABASE)
# SQLALCHEMY_TRACK_MODIFICATIONS = False

#db名为test
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:123456@localhost:3306/test?charset=utf8'
SQLALCHEMY_TRACK_MODIFICATIONS = False